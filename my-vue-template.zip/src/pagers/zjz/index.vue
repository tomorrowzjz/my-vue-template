<template>
  <div class='zjz'><div/>
</template>

<script>
export default {
  name: 'zjz',
  props: {},
  data() {
    return {}
  },
  created() {},
  mounted() {},
  methods: {}
}
</script>

<style lang="scss" scoped>

</style>
