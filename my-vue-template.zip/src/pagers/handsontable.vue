<template>
    <hot-table :settings="hotSettings"></hot-table>
</template>

<script>
  import { HotTable } from '@handsontable/vue';
  import Handsontable from 'handsontable';
  import 'handsontable/languages/zh-CN';
  import 'handsontable-pro/languages/zh-CN';
  export default {
    data: function() {
      return {
        hotSettings: {
          data: Handsontable.helper.createSpreadsheetData(5, 5),
          colHeaders: true,
          contextMenu: true,
          language: 'zh-CN'
        }
      }
    },
    components: {
      HotTable
    }
  }
</script>
<style>
    @import "https://cdn.jsdelivr.net/npm/handsontable@6.2.2/dist/handsontable.full.min.css";
</style>
