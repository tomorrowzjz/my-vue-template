<template>
  <transition name="fade-transform" mode="out-in">
    <keep-alive>
      <router-view/>
    </keep-alive>
  </transition>
</template>

<script>
  export default {
    name: '',
    data () {
      return {
        msg: 'Welcome to Your Vue.js App'
      }
    }
  }
</script>

<style scoped>

</style>
